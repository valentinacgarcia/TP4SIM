﻿namespace RelojeriaColas
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.labelTitle = new System.Windows.Forms.Label();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.labelSeparator = new System.Windows.Forms.Label();
            this.groupBoxParameters = new System.Windows.Forms.GroupBox();
            this.buttonSimulate = new System.Windows.Forms.Button();
            this.textBoxTiempoArrelgoH = new System.Windows.Forms.TextBox();
            this.textBoxTiempoArregloD = new System.Windows.Forms.TextBox();
            this.labelFixParentesis = new System.Windows.Forms.Label();
            this.labelFixComa = new System.Windows.Forms.Label();
            this.labelFix = new System.Windows.Forms.Label();
            this.textBoxTiempoCompraH = new System.Windows.Forms.TextBox();
            this.textBoxTiempoCompraD = new System.Windows.Forms.TextBox();
            this.labelParenthesisTime = new System.Windows.Forms.Label();
            this.labelComaTime = new System.Windows.Forms.Label();
            this.labelBuyTime = new System.Windows.Forms.Label();
            this.labelRetireP = new System.Windows.Forms.Label();
            this.labelGiveP = new System.Windows.Forms.Label();
            this.labelBuyP = new System.Windows.Forms.Label();
            this.textBoxLlegadaClientesH = new System.Windows.Forms.TextBox();
            this.textBoxLlegadaClientesD = new System.Windows.Forms.TextBox();
            this.labelParentesis = new System.Windows.Forms.Label();
            this.labelComa = new System.Windows.Forms.Label();
            this.textBoxPRetirar = new System.Windows.Forms.TextBox();
            this.labelClientsDistribution = new System.Windows.Forms.Label();
            this.textBoxCantidadIteraciones = new System.Windows.Forms.TextBox();
            this.textBoxPEntregar = new System.Windows.Forms.TextBox();
            this.textBoxIteraciones = new System.Windows.Forms.TextBox();
            this.textBoxPComprar = new System.Windows.Forms.TextBox();
            this.textBoxTiempoSimulacion = new System.Windows.Forms.TextBox();
            this.labelQuantityIterations = new System.Windows.Forms.Label();
            this.labelFromIteration = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.dataGridViewFromRowToRow = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewLastRow = new System.Windows.Forms.DataGridView();
            this.labelStats = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.groupBoxParameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFromRowToRow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLastRow)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(139, 65);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(595, 34);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Sistema de Simulacion de Colas: Relojería";
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.BackgroundImage = global::RelojeriaColas.Properties.Resources.Magis_Tempo_Wanduhr_1200x630_ID44985_06bdd38c7275d8e72f4f0f1ebcced337;
            this.pictureBoxTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxTitle.ErrorImage = global::RelojeriaColas.Properties.Resources.Magis_Tempo_Wanduhr_1200x630_ID44985_06bdd38c7275d8e72f4f0f1ebcced337;
            this.pictureBoxTitle.InitialImage = global::RelojeriaColas.Properties.Resources.Magis_Tempo_Wanduhr_1200x630_ID44985_06bdd38c7275d8e72f4f0f1ebcced337;
            this.pictureBoxTitle.Location = new System.Drawing.Point(21, 40);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(151, 82);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 1;
            this.pictureBoxTitle.TabStop = false;
            // 
            // labelSeparator
            // 
            this.labelSeparator.AutoSize = true;
            this.labelSeparator.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeparator.Location = new System.Drawing.Point(-9, 84);
            this.labelSeparator.Name = "labelSeparator";
            this.labelSeparator.Size = new System.Drawing.Size(1931, 91);
            this.labelSeparator.TabIndex = 2;
            this.labelSeparator.Text = "___________________________________________";
            // 
            // groupBoxParameters
            // 
            this.groupBoxParameters.Controls.Add(this.buttonSimulate);
            this.groupBoxParameters.Controls.Add(this.textBoxTiempoArrelgoH);
            this.groupBoxParameters.Controls.Add(this.textBoxTiempoArregloD);
            this.groupBoxParameters.Controls.Add(this.labelFixParentesis);
            this.groupBoxParameters.Controls.Add(this.labelFixComa);
            this.groupBoxParameters.Controls.Add(this.labelFix);
            this.groupBoxParameters.Controls.Add(this.textBoxTiempoCompraH);
            this.groupBoxParameters.Controls.Add(this.textBoxTiempoCompraD);
            this.groupBoxParameters.Controls.Add(this.labelParenthesisTime);
            this.groupBoxParameters.Controls.Add(this.labelComaTime);
            this.groupBoxParameters.Controls.Add(this.labelBuyTime);
            this.groupBoxParameters.Controls.Add(this.labelRetireP);
            this.groupBoxParameters.Controls.Add(this.labelGiveP);
            this.groupBoxParameters.Controls.Add(this.labelBuyP);
            this.groupBoxParameters.Controls.Add(this.textBoxLlegadaClientesH);
            this.groupBoxParameters.Controls.Add(this.textBoxLlegadaClientesD);
            this.groupBoxParameters.Controls.Add(this.labelParentesis);
            this.groupBoxParameters.Controls.Add(this.labelComa);
            this.groupBoxParameters.Controls.Add(this.textBoxPRetirar);
            this.groupBoxParameters.Controls.Add(this.labelClientsDistribution);
            this.groupBoxParameters.Controls.Add(this.textBoxCantidadIteraciones);
            this.groupBoxParameters.Controls.Add(this.textBoxPEntregar);
            this.groupBoxParameters.Controls.Add(this.textBoxIteraciones);
            this.groupBoxParameters.Controls.Add(this.textBoxPComprar);
            this.groupBoxParameters.Controls.Add(this.textBoxTiempoSimulacion);
            this.groupBoxParameters.Controls.Add(this.labelQuantityIterations);
            this.groupBoxParameters.Controls.Add(this.labelFromIteration);
            this.groupBoxParameters.Controls.Add(this.labelTime);
            this.groupBoxParameters.Location = new System.Drawing.Point(866, 12);
            this.groupBoxParameters.Name = "groupBoxParameters";
            this.groupBoxParameters.Size = new System.Drawing.Size(1137, 141);
            this.groupBoxParameters.TabIndex = 3;
            this.groupBoxParameters.TabStop = false;
            this.groupBoxParameters.Text = "Parámetros";
            // 
            // buttonSimulate
            // 
            this.buttonSimulate.Location = new System.Drawing.Point(993, 48);
            this.buttonSimulate.Name = "buttonSimulate";
            this.buttonSimulate.Size = new System.Drawing.Size(125, 52);
            this.buttonSimulate.TabIndex = 24;
            this.buttonSimulate.Text = "Simular";
            this.buttonSimulate.UseVisualStyleBackColor = true;
            this.buttonSimulate.Click += new System.EventHandler(this.BotonSimular);
            // 
            // textBoxTiempoArrelgoH
            // 
            this.textBoxTiempoArrelgoH.Location = new System.Drawing.Point(873, 90);
            this.textBoxTiempoArrelgoH.Name = "textBoxTiempoArrelgoH";
            this.textBoxTiempoArrelgoH.Size = new System.Drawing.Size(58, 22);
            this.textBoxTiempoArrelgoH.TabIndex = 23;
            this.textBoxTiempoArrelgoH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTiempoArregloH_KeyPress);
            // 
            // textBoxTiempoArregloD
            // 
            this.textBoxTiempoArregloD.Location = new System.Drawing.Point(795, 90);
            this.textBoxTiempoArregloD.Name = "textBoxTiempoArregloD";
            this.textBoxTiempoArregloD.Size = new System.Drawing.Size(58, 22);
            this.textBoxTiempoArregloD.TabIndex = 22;
            this.textBoxTiempoArregloD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTiempoArregloD_KeyPress);
            // 
            // labelFixParentesis
            // 
            this.labelFixParentesis.AutoSize = true;
            this.labelFixParentesis.Location = new System.Drawing.Point(931, 93);
            this.labelFixParentesis.Name = "labelFixParentesis";
            this.labelFixParentesis.Size = new System.Drawing.Size(11, 16);
            this.labelFixParentesis.TabIndex = 21;
            this.labelFixParentesis.Text = ")";
            // 
            // labelFixComa
            // 
            this.labelFixComa.AutoSize = true;
            this.labelFixComa.Location = new System.Drawing.Point(860, 93);
            this.labelFixComa.Name = "labelFixComa";
            this.labelFixComa.Size = new System.Drawing.Size(10, 16);
            this.labelFixComa.TabIndex = 20;
            this.labelFixComa.Text = ";";
            // 
            // labelFix
            // 
            this.labelFix.AutoSize = true;
            this.labelFix.Location = new System.Drawing.Point(647, 93);
            this.labelFix.Name = "labelFix";
            this.labelFix.Size = new System.Drawing.Size(139, 16);
            this.labelFix.TabIndex = 19;
            this.labelFix.Text = "Tiempo de arreglo: U(";
            // 
            // textBoxTiempoCompraH
            // 
            this.textBoxTiempoCompraH.Location = new System.Drawing.Point(563, 90);
            this.textBoxTiempoCompraH.Name = "textBoxTiempoCompraH";
            this.textBoxTiempoCompraH.Size = new System.Drawing.Size(58, 22);
            this.textBoxTiempoCompraH.TabIndex = 18;
            this.textBoxTiempoCompraH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTiempoCompraH_KeyPress);
            // 
            // textBoxTiempoCompraD
            // 
            this.textBoxTiempoCompraD.Location = new System.Drawing.Point(485, 90);
            this.textBoxTiempoCompraD.Name = "textBoxTiempoCompraD";
            this.textBoxTiempoCompraD.Size = new System.Drawing.Size(58, 22);
            this.textBoxTiempoCompraD.TabIndex = 17;
            this.textBoxTiempoCompraD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTiempoCompraD_KeyPress);
            // 
            // labelParenthesisTime
            // 
            this.labelParenthesisTime.AutoSize = true;
            this.labelParenthesisTime.Location = new System.Drawing.Point(621, 93);
            this.labelParenthesisTime.Name = "labelParenthesisTime";
            this.labelParenthesisTime.Size = new System.Drawing.Size(11, 16);
            this.labelParenthesisTime.TabIndex = 16;
            this.labelParenthesisTime.Text = ")";
            // 
            // labelComaTime
            // 
            this.labelComaTime.AutoSize = true;
            this.labelComaTime.Location = new System.Drawing.Point(550, 93);
            this.labelComaTime.Name = "labelComaTime";
            this.labelComaTime.Size = new System.Drawing.Size(10, 16);
            this.labelComaTime.TabIndex = 15;
            this.labelComaTime.Text = ";";
            // 
            // labelBuyTime
            // 
            this.labelBuyTime.AutoSize = true;
            this.labelBuyTime.Location = new System.Drawing.Point(337, 93);
            this.labelBuyTime.Name = "labelBuyTime";
            this.labelBuyTime.Size = new System.Drawing.Size(142, 16);
            this.labelBuyTime.TabIndex = 14;
            this.labelBuyTime.Text = "Tiempo de compra: U(";
            // 
            // labelRetireP
            // 
            this.labelRetireP.AutoSize = true;
            this.labelRetireP.Location = new System.Drawing.Point(649, 59);
            this.labelRetireP.Name = "labelRetireP";
            this.labelRetireP.Size = new System.Drawing.Size(140, 16);
            this.labelRetireP.TabIndex = 13;
            this.labelRetireP.Text = "Probabilidad de retiro:";
            // 
            // labelGiveP
            // 
            this.labelGiveP.AutoSize = true;
            this.labelGiveP.Location = new System.Drawing.Point(331, 56);
            this.labelGiveP.Name = "labelGiveP";
            this.labelGiveP.Size = new System.Drawing.Size(156, 16);
            this.labelGiveP.TabIndex = 12;
            this.labelGiveP.Text = "Probabilidad de entrega:";
            // 
            // labelBuyP
            // 
            this.labelBuyP.AutoSize = true;
            this.labelBuyP.Location = new System.Drawing.Point(20, 56);
            this.labelBuyP.Name = "labelBuyP";
            this.labelBuyP.Size = new System.Drawing.Size(160, 16);
            this.labelBuyP.TabIndex = 11;
            this.labelBuyP.Text = "Probabilidad de comprar:";
            // 
            // textBoxLlegadaClientesH
            // 
            this.textBoxLlegadaClientesH.Location = new System.Drawing.Point(259, 87);
            this.textBoxLlegadaClientesH.Name = "textBoxLlegadaClientesH";
            this.textBoxLlegadaClientesH.Size = new System.Drawing.Size(58, 22);
            this.textBoxLlegadaClientesH.TabIndex = 15;
            this.textBoxLlegadaClientesH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLlegadaClientesH_KeyPress);
            // 
            // textBoxLlegadaClientesD
            // 
            this.textBoxLlegadaClientesD.Location = new System.Drawing.Point(181, 87);
            this.textBoxLlegadaClientesD.Name = "textBoxLlegadaClientesD";
            this.textBoxLlegadaClientesD.Size = new System.Drawing.Size(58, 22);
            this.textBoxLlegadaClientesD.TabIndex = 14;
            this.textBoxLlegadaClientesD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLlegadaClientesD_KeyPress);
            // 
            // labelParentesis
            // 
            this.labelParentesis.AutoSize = true;
            this.labelParentesis.Location = new System.Drawing.Point(317, 90);
            this.labelParentesis.Name = "labelParentesis";
            this.labelParentesis.Size = new System.Drawing.Size(11, 16);
            this.labelParentesis.TabIndex = 8;
            this.labelParentesis.Text = ")";
            // 
            // labelComa
            // 
            this.labelComa.AutoSize = true;
            this.labelComa.Location = new System.Drawing.Point(246, 90);
            this.labelComa.Name = "labelComa";
            this.labelComa.Size = new System.Drawing.Size(10, 16);
            this.labelComa.TabIndex = 7;
            this.labelComa.Text = ";";
            // 
            // textBoxPRetirar
            // 
            this.textBoxPRetirar.Location = new System.Drawing.Point(795, 56);
            this.textBoxPRetirar.Name = "textBoxPRetirar";
            this.textBoxPRetirar.Size = new System.Drawing.Size(100, 22);
            this.textBoxPRetirar.TabIndex = 13;
            this.textBoxPRetirar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPRetirar_KeyPress);
            // 
            // labelClientsDistribution
            // 
            this.labelClientsDistribution.AutoSize = true;
            this.labelClientsDistribution.Location = new System.Drawing.Point(51, 90);
            this.labelClientsDistribution.Name = "labelClientsDistribution";
            this.labelClientsDistribution.Size = new System.Drawing.Size(126, 16);
            this.labelClientsDistribution.TabIndex = 6;
            this.labelClientsDistribution.Text = "Llegada clientes: U(";
            // 
            // textBoxCantidadIteraciones
            // 
            this.textBoxCantidadIteraciones.Location = new System.Drawing.Point(795, 15);
            this.textBoxCantidadIteraciones.Name = "textBoxCantidadIteraciones";
            this.textBoxCantidadIteraciones.Size = new System.Drawing.Size(100, 22);
            this.textBoxCantidadIteraciones.TabIndex = 5;
            this.textBoxCantidadIteraciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCantidadIteraciones_KeyPress);
            // 
            // textBoxPEntregar
            // 
            this.textBoxPEntregar.Location = new System.Drawing.Point(501, 53);
            this.textBoxPEntregar.Name = "textBoxPEntregar";
            this.textBoxPEntregar.Size = new System.Drawing.Size(100, 22);
            this.textBoxPEntregar.TabIndex = 12;
            this.textBoxPEntregar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPEntregar_KeyPress);
            // 
            // textBoxIteraciones
            // 
            this.textBoxIteraciones.Location = new System.Drawing.Point(502, 15);
            this.textBoxIteraciones.Name = "textBoxIteraciones";
            this.textBoxIteraciones.Size = new System.Drawing.Size(100, 22);
            this.textBoxIteraciones.TabIndex = 4;
            this.textBoxIteraciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxIteraciones_KeyPress);
            // 
            // textBoxPComprar
            // 
            this.textBoxPComprar.Location = new System.Drawing.Point(184, 53);
            this.textBoxPComprar.Name = "textBoxPComprar";
            this.textBoxPComprar.Size = new System.Drawing.Size(100, 22);
            this.textBoxPComprar.TabIndex = 9;
            this.textBoxPComprar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPComprar_KeyPress);
            // 
            // textBoxTiempoSimulacion
            // 
            this.textBoxTiempoSimulacion.Location = new System.Drawing.Point(186, 15);
            this.textBoxTiempoSimulacion.Name = "textBoxTiempoSimulacion";
            this.textBoxTiempoSimulacion.Size = new System.Drawing.Size(100, 22);
            this.textBoxTiempoSimulacion.TabIndex = 3;
            this.textBoxTiempoSimulacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTiempoSimulacion_KeyPress);
            // 
            // labelQuantityIterations
            // 
            this.labelQuantityIterations.AutoSize = true;
            this.labelQuantityIterations.Location = new System.Drawing.Point(623, 18);
            this.labelQuantityIterations.Name = "labelQuantityIterations";
            this.labelQuantityIterations.Size = new System.Drawing.Size(166, 16);
            this.labelQuantityIterations.TabIndex = 2;
            this.labelQuantityIterations.Text = "Cantidad de iteraciones (i):";
            // 
            // labelFromIteration
            // 
            this.labelFromIteration.AutoSize = true;
            this.labelFromIteration.Location = new System.Drawing.Point(322, 21);
            this.labelFromIteration.Name = "labelFromIteration";
            this.labelFromIteration.Size = new System.Drawing.Size(165, 16);
            this.labelFromIteration.TabIndex = 1;
            this.labelFromIteration.Text = "Mostrar desde iteración (j):";
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Location = new System.Drawing.Point(18, 18);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(162, 16);
            this.labelTime.TabIndex = 0;
            this.labelTime.Text = "Tiempo de simulación (X):";
            // 
            // dataGridViewFromRowToRow
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.NullValue = "-";
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewFromRowToRow.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewFromRowToRow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewFromRowToRow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.NullValue = "-";
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewFromRowToRow.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewFromRowToRow.Location = new System.Drawing.Point(21, 221);
            this.dataGridViewFromRowToRow.Name = "dataGridViewFromRowToRow";
            this.dataGridViewFromRowToRow.RowHeadersVisible = false;
            this.dataGridViewFromRowToRow.RowHeadersWidth = 51;
            this.dataGridViewFromRowToRow.RowTemplate.Height = 24;
            this.dataGridViewFromRowToRow.Size = new System.Drawing.Size(1994, 603);
            this.dataGridViewFromRowToRow.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 827);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ultima Fila";
            // 
            // dataGridViewLastRow
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.NullValue = "-";
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLastRow.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewLastRow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewLastRow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLastRow.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewLastRow.Location = new System.Drawing.Point(21, 859);
            this.dataGridViewLastRow.Name = "dataGridViewLastRow";
            this.dataGridViewLastRow.RowHeadersVisible = false;
            this.dataGridViewLastRow.RowHeadersWidth = 51;
            this.dataGridViewLastRow.RowTemplate.Height = 24;
            this.dataGridViewLastRow.Size = new System.Drawing.Size(1994, 77);
            this.dataGridViewLastRow.TabIndex = 6;
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStats.Location = new System.Drawing.Point(29, 175);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(0, 29);
            this.labelStats.TabIndex = 7;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1332, 753);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.dataGridViewLastRow);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewFromRowToRow);
            this.Controls.Add(this.groupBoxParameters);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.pictureBoxTitle);
            this.Controls.Add(this.labelSeparator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Simulacion Colas Relojeria";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.groupBoxParameters.ResumeLayout(false);
            this.groupBoxParameters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFromRowToRow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLastRow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.Label labelSeparator;
        private System.Windows.Forms.GroupBox groupBoxParameters;
        private System.Windows.Forms.Label labelFromIteration;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labelQuantityIterations;
        private System.Windows.Forms.TextBox textBoxCantidadIteraciones;
        private System.Windows.Forms.TextBox textBoxIteraciones;
        private System.Windows.Forms.TextBox textBoxTiempoSimulacion;
        private System.Windows.Forms.TextBox textBoxLlegadaClientesH;
        private System.Windows.Forms.TextBox textBoxLlegadaClientesD;
        private System.Windows.Forms.Label labelParentesis;
        private System.Windows.Forms.Label labelComa;
        private System.Windows.Forms.Label labelClientsDistribution;
        private System.Windows.Forms.Label labelRetireP;
        private System.Windows.Forms.Label labelGiveP;
        private System.Windows.Forms.Label labelBuyP;
        private System.Windows.Forms.TextBox textBoxPRetirar;
        private System.Windows.Forms.TextBox textBoxPEntregar;
        private System.Windows.Forms.TextBox textBoxPComprar;
        private System.Windows.Forms.TextBox textBoxTiempoCompraH;
        private System.Windows.Forms.TextBox textBoxTiempoCompraD;
        private System.Windows.Forms.Label labelParenthesisTime;
        private System.Windows.Forms.Label labelComaTime;
        private System.Windows.Forms.Label labelBuyTime;
        private System.Windows.Forms.TextBox textBoxTiempoArrelgoH;
        private System.Windows.Forms.TextBox textBoxTiempoArregloD;
        private System.Windows.Forms.Label labelFixParentesis;
        private System.Windows.Forms.Label labelFixComa;
        private System.Windows.Forms.Label labelFix;
        private System.Windows.Forms.Button buttonSimulate;
        private System.Windows.Forms.DataGridView dataGridViewFromRowToRow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewLastRow;
        private System.Windows.Forms.Label labelStats;
    }
}

