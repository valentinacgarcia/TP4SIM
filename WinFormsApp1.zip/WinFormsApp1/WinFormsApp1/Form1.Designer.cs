﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            textBoxIteraciones = new TextBox();
            button1 = new Button();
            textBoxMinutoInicio = new TextBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 132);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(776, 306);
            dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 44);
            label1.Name = "label1";
            label1.Size = new Size(175, 15);
            label1.TabIndex = 1;
            label1.Text = "Ingrese la cantidad de minutos: ";
            // 
            // textBoxIteraciones
            // 
            textBoxIteraciones.Location = new Point(193, 41);
            textBoxIteraciones.Name = "textBoxIteraciones";
            textBoxIteraciones.Size = new Size(100, 23);
            textBoxIteraciones.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(684, 101);
            button1.Name = "button1";
            button1.Size = new Size(104, 25);
            button1.TabIndex = 3;
            button1.Text = "SIMULAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBoxMinutoInicio
            // 
            textBoxMinutoInicio.Location = new Point(290, 78);
            textBoxMinutoInicio.Name = "textBoxMinutoInicio";
            textBoxMinutoInicio.Size = new Size(100, 23);
            textBoxMinutoInicio.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 81);
            label2.Name = "label2";
            label2.Size = new Size(272, 15);
            label2.TabIndex = 4;
            label2.Text = "Ingrese el minuto a partir de cual minuto mostrar: ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBoxMinutoInicio);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(textBoxIteraciones);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private TextBox textBoxIteraciones;
        private Button button1;
        private TextBox textBoxMinutoInicio;
        private Label label2;
    }
}