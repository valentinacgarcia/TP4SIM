using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using static WinFormsApp1.Form1;



namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        int cantidadMinutos;
        int cantidadIteraciones = 0;
        DataTable tabla_simulacion = new DataTable();
        Random rnd_atencion_relojero = new Random();
        Random randomVenta = new Random();
        Random randomLlegada = new Random();
        Random rndAtencion = new Random();
        Random rndAtencionRelojero = new Random();
        Random rndCafe = new Random();
        double relojActual;
        double tiempoLlegadaCliente = 0;
        Queue<Cliente> colaClientes = new Queue<Cliente>();
        List<Cliente> clientes = new List<Cliente>();
        List<Cliente> clientesA = new List<Cliente>();
        List<Cliente> clientesR = new List<Cliente>();
        Ayudante ayudante = new Ayudante();
        Relojero relojero = new Relojero();

        Relojero miRelojero;

        public Form1()
        {
            InitializeComponent();
            relojActual = 0;
            miRelojero = new Relojero();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Relojero miRelojero = new Relojero();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cantidadIteraciones = int.Parse(textBoxIteraciones.Text);
                Simular();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurri� un error en la simulaci�n: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Simular()
        {
            if (!int.TryParse(textBoxIteraciones.Text, out int tiempoSimulacion))
            {
                MessageBox.Show("Valor de tiempo de simulaci�n incorrecto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int minutoInicio = 0; 

            int minutoFin = minutoInicio + tiempoSimulacion;

            Queue<Cliente> clientesSimulados = new Queue<Cliente>();

            Cliente clienteAnterior = null; 
            int contadorClientesAgregados = 0; 

            for (int i = 0; i < cantidadIteraciones; i++)
            {

                Cliente nuevoCliente;

                if (i == 0)
                {
                    nuevoCliente = new Cliente();
                    nuevoCliente.MinutoLlegada = 0;
                    nuevoCliente.calcularLlegada(randomLlegada); 
                    nuevoCliente.CalcularRelojLlegadaCliente(); 
                    nuevoCliente.RndAtencion = 0;
                    nuevoCliente.AtencionARealizar = " ";
                }
                else
                {
                    nuevoCliente = new Cliente();
                    nuevoCliente.MinutoLlegada = clienteAnterior.RelojCliente;
                    nuevoCliente.calcularLlegada(randomLlegada); 
                    nuevoCliente.CalcularRelojLlegadaCliente(); 
                    nuevoCliente.CalcularAtencionTipo(rndAtencion);
                }

                
                if (nuevoCliente.MinutoLlegada >= minutoInicio && nuevoCliente.MinutoLlegada <= minutoFin)
                {
                    clientesSimulados.Enqueue(nuevoCliente); 
                    contadorClientesAgregados++;
                }
                else if (contadorClientesAgregados > 0)
                {
                    
                    break;
                }

                
                relojActual += nuevoCliente.MinutoLlegada;

                
                clienteAnterior = nuevoCliente;
            }

            Queue<Simulacion> simulaciones = new Queue<Simulacion>(); 
            Random randomVenta = new Random(); 
            Simulacion simulacionAnterior = null; 
            int contadorClientesAgregadosS = 0; 

            foreach (Cliente cliente in clientesSimulados)
            {
                Simulacion simulacion = new Simulacion(cliente, randomVenta);

                
                simulacion.Evento = "Llegada Cliente " + contadorClientesAgregados;
                simulacion.Reloj = cliente.MinutoLlegada; 
                
                if (simulacion.Reloj == 0)
                {
                    simulacion.RelojFinVenta = 0;
                    simulacion.TiempoVenta = 0;
                    simulacion.RndTiempoVenta = 0;
                    simulacion.TiempoEntrega = 0;
                    simulacion.TiempoRetiro = 0;
                    simulacion.RelojTiempoEntrega = 0;
                    simulacion.RelojTiempoRetiro = 0;
                   
                    
                }
                else
                {
                    
                    simulacion.CalcularRelojTiempoRetiro();
                    simulacion.CalcularRelojTiempoEntrega();
                    simulacion.CalcularTiempoEntrega();
                    simulacion.CalcularTiempoRetiro();

                }
                

                
                simulaciones.Enqueue(simulacion);
            }

            cargarDatosTabla(simulaciones, minutoInicio, ayudante, relojero);

            
        }



        public void cargarDatosTabla(Queue<Simulacion> simulaciones, int minutoInicio, Ayudante ayudante, Relojero relojero)
        {
            
            tabla_simulacion.Clear();

            
            tabla_simulacion.Columns.Add("Reloj", typeof(double)); 
            tabla_simulacion.Columns.Add("Evento", typeof(string));
            tabla_simulacion.Columns.Add("Rnd Llegada Cliente", typeof(double));
            tabla_simulacion.Columns.Add("Llegada cliente", typeof(double));
            tabla_simulacion.Columns.Add("Reloj Llegada Cliente", typeof(double));
            tabla_simulacion.Columns.Add("Estado Ayudante", typeof(string));
            tabla_simulacion.Columns.Add("Cola Ayudante", typeof(int));
            tabla_simulacion.Columns.Add("Rnd Atencion a Realizar", typeof(double));
            tabla_simulacion.Columns.Add("Atencion a Realizar", typeof(string));
            tabla_simulacion.Columns.Add("Rnd Tiempo Venta", typeof(double));
            tabla_simulacion.Columns.Add("Tiempo Venta", typeof(double));
            tabla_simulacion.Columns.Add("Reloj Fin Venta", typeof(double));
            tabla_simulacion.Columns.Add("Tiempo Retiro", typeof(double));
            tabla_simulacion.Columns.Add("Reloj Tiempo Retiro", typeof(double));
            tabla_simulacion.Columns.Add("Tiempo Entrega", typeof(double));
            tabla_simulacion.Columns.Add("Reloj Tiempo Entrega", typeof(double));
            tabla_simulacion.Columns.Add("Estado Relojero", typeof(string));
            tabla_simulacion.Columns.Add("Cola Relojes a reparar", typeof(int));
            tabla_simulacion.Columns.Add("Rnd Reparacion Reloj", typeof(double));
            tabla_simulacion.Columns.Add("Tiempo Reparacion Reloj", typeof(double));
            tabla_simulacion.Columns.Add("Momento Fin Reparacion", typeof(double));
            tabla_simulacion.Columns.Add("Rnd Cafe", typeof(double));
            tabla_simulacion.Columns.Add("Cafe", typeof(string));
            tabla_simulacion.Columns.Add("Tiempo Cafe", typeof(double));
            tabla_simulacion.Columns.Add("Reloj Fin Cafe", typeof(double));
            tabla_simulacion.Columns.Add("Cola Relojes a retirar", typeof(int));

            double relojActual = minutoInicio; 

            int numeroCliente = 0; 

            foreach (Simulacion simulacion in simulaciones)
            {
                Cliente cliente = simulacion.ClienteRelacionado; 

                if (cliente.LlegadaCliente >= minutoInicio)
                {
                    numeroCliente++; // Incrementar el n�mero de cliente
                    tabla_simulacion.Rows.Add(
                        simulacion.Reloj, // Minuto Llegada
                        "Llegada Cliente " + numeroCliente, // Evento (n�mero de cliente)
                        cliente.RndLlegadaCliente, // Rnd Llegada Cliente
                        cliente.LlegadaCliente, // Llegada cliente
                        cliente.RelojCliente, // Reloj Llegada Cliente
                        ayudante.Estado, // Estado Ayudante
                        ayudante.ColaClientesA.Count, // Cola Ayudante
                        cliente.RndAtencion, // Rnd Atencion a Realizar
                        cliente.AtencionARealizar, // Atencion a Realizar
                        simulacion.RndTiempoVenta, // Rnd Tiempo Venta
                        simulacion.TiempoVenta, // Tiempo Venta
                        simulacion.RelojFinVenta, // Reloj Fin Venta
                        simulacion.TiempoRetiro, // Tiempo Retiro
                        simulacion.RelojTiempoRetiro, // Reloj Tiempo Retiro
                        simulacion.TiempoEntrega, // Tiempo Entrega
                        simulacion.RelojTiempoEntrega, // Reloj Tiempo Entrega
                        relojero.Estado, // Estado Relojero
                        relojero.ColaRelojesPorReparar.Count, // Cola Relojes a reparar
                        relojero.RndReparacionReloj, // Rnd Reparacion Reloj
                        relojero.TiempoReparacionReloj, // Tiempo Reparacion Reloj
                        relojero.MomentoFinReparacion, // Momento Fin Reparacion
                        relojero.RndCafe, // Rnd Cafe
                        relojero.Cafe, // Cafe
                        relojero.TiempoCafe, // Tiempo Cafe
                        relojero.RelojFinCafe, // Reloj Fin Cafe
                        relojero.ColaRelojesParaRetirar.Count
                                        );

                    relojActual += cliente.MinutoLlegada;
                }
            }

            
            dataGridView1.DataSource = tabla_simulacion;
        }
        public class Simulacion
        {
            public string Evento { get; set; } 
            public double Reloj { get; set; } 
            public Cliente ClienteRelacionado { get; set; }
            public double RndTiempoVenta { get; set; }
            public double TiempoVenta { get; set; }
            public double RelojFinVenta { get; set; }
            public double TiempoRetiro { get; set; }
            public double RelojTiempoRetiro { get; set; }
            public double TiempoEntrega { get; set; }
            public double RelojTiempoEntrega { get; set; }

            public Simulacion(Cliente cliente, Random randomVenta)
            {
                ClienteRelacionado = cliente;
                CalcularFinVenta(randomVenta);
                CalcularRelojFinVenta(randomVenta);
                CalcularTiempoRetiro();
                CalcularRelojTiempoRetiro();
                CalcularTiempoEntrega();
                CalcularRelojTiempoEntrega();
            }
            public void CalcularFinVenta(Random randomVenta)
            {
                double rndV, tiempoV;

                if (ClienteRelacionado.AtencionARealizar == "Compra de reloj")
                {
                    rndV = randomVenta.NextDouble();
                    rndV = Math.Round(rndV * 1000) / 1000; 
                    tiempoV = 6 + rndV * (10 - 6); // Calcula el tiempo de venta
                }
                else
                {
                    rndV = 0; 
                    tiempoV = 0; 
                }

                RndTiempoVenta = rndV;
                TiempoVenta = tiempoV;
                RelojFinVenta = ClienteRelacionado.MinutoLlegada + tiempoV;
            }
            public void CalcularRelojFinVenta(Random randomVenta)
            {
                if (ClienteRelacionado != null)
                {
                    if (ClienteRelacionado.AtencionARealizar == "Compra de reloj")
                    {
                        CalcularFinVenta(randomVenta); 
                        RelojFinVenta = ClienteRelacionado.MinutoLlegada + TiempoVenta; 
                    }
                    else
                    {
                        RelojFinVenta = 0; 
                    }
                }
                else
                {
                    RelojFinVenta = 0; 
                }
            }


            public void CalcularTiempoRetiro()
            {
                if (ClienteRelacionado.AtencionARealizar == "Retiro de reloj")
                {
                    TiempoRetiro = 3;
                }
                else
                {
                    TiempoRetiro = 0; // Establece un valor por defecto en caso de que la atenci�n no sea "Retiro de reloj"
                }
            }

            public void CalcularRelojTiempoRetiro()
            {
                if (ClienteRelacionado.AtencionARealizar == "Retiro de reloj")
                {
                    RelojTiempoRetiro = TiempoRetiro + Reloj;
                }
                else
                {
                    RelojTiempoRetiro = 0; // Si la atenci�n es Entrega o Compra de reloj, el valor es NaN
                }
            }

            public void CalcularTiempoEntrega()
            {
                if (ClienteRelacionado.AtencionARealizar == "Entrega de reloj")
                {
                    TiempoEntrega = 3;
                }
                else
                {
                    TiempoEntrega = 0; // Si la atenci�n es Retiro o Compra de reloj, el valor es NaN
                }
            }

            public void CalcularRelojTiempoEntrega()
            {
                if (ClienteRelacionado.AtencionARealizar == "Entrega de reloj")
                {
                    RelojTiempoEntrega = Reloj + TiempoEntrega;
                }
                else
                {
                    RelojTiempoEntrega = 0; // Si la atenci�n es Entrega o Compra de reloj, el valor es NaN
                }

            }
        }
        public class Cliente
        {
            public double MinutoLlegada { get; set; }
            public double RelojCliente { get; set; }
            public double RndAtencion { get; set; }
            public string AtencionARealizar { get; set; }
            public double RndLlegadaCliente { get; set; }
            public double LlegadaCliente { get; set; }

            public Cliente()
            {
                
            }
            public void CalcularAtencionTipo(Random rndAtencion)
            {
                double numeroAleatorio = rndAtencion.NextDouble();
                numeroAleatorio = Math.Round(numeroAleatorio * 1000) / 1000; // Redondea a 3 decimales
                if (numeroAleatorio < 0.45)
                {
                    RndAtencion = numeroAleatorio;
                    AtencionARealizar = "Compra de reloj";
                }
                else if (numeroAleatorio < 0.70)
                {
                    RndAtencion = numeroAleatorio;
                    AtencionARealizar = "Entrega de reloj";
                }
                else
                {
                    RndAtencion = numeroAleatorio;
                    AtencionARealizar = "Retiro de reloj";
                }
            }
            public void calcularLlegada(Random randomLlegada)
            {
                double numeroAleatorio = randomLlegada.NextDouble();
                numeroAleatorio = Math.Round(numeroAleatorio * 1000) / 1000; // Redondea a 3 decimales
                RndLlegadaCliente = numeroAleatorio;
                LlegadaCliente = 13 + numeroAleatorio * (17 - 13);
            }


            public void CalcularRelojLlegadaCliente()
            {
                
                if (LlegadaCliente >= 0) 
                {
                    RelojCliente = MinutoLlegada + LlegadaCliente; 
                }
                
            }
        }
        public class Ayudante
        {
            public enum Estados { Libre, Ocupado }

            public Estados Estado { get; set; }
            public double FinAtencion { get; set; }
            public double RndLlegadaCliente { get; set; }
            public Cliente ClienteAtendido { get; set; }
            public int RetiradosSinReparar { get; set; }
            public int RetiradosReparados { get; set; }
            private Random rnd_atencion_relojero;
            private Queue<Cliente> colaClientesA;
            public Queue<Cliente> ColaClientesA { get; set; } = new Queue<Cliente>();


            public Ayudante()
            {
                Estado = Estados.Libre;
                rnd_atencion_relojero = new Random();
                colaClientesA = new Queue<Cliente>();
            }

            public void AtenderCliente(Cliente cliente, string tipoAtencion, double relojActual)
            {
                if (Estado == Estados.Libre)
                {
                    ClienteAtendido = cliente;
                    Estado = Estados.Ocupado;

                    // Asigna el valor de RndLlegadaCliente al cliente actual que est�s atendiendo
                    cliente.RndLlegadaCliente = RndLlegadaCliente;

                    if (tipoAtencion == "Compra de reloj")
                    {
                        calcularFinDeVenta(relojActual);
                    }
                    else
                    {
                        FinAtencion = relojActual + 3;

                        if (RandomDouble() < 0.3)
                        {
                            if (cliente.MinutoLlegada <= relojActual)
                            {
                                RetiradosSinReparar++;
                            }
                            else
                            {
                                RetiradosReparados++;
                            }
                        }
                    }
                }
                else
                {
                    // Si el ayudante est� ocupado, agrega al cliente a la cola
                    colaClientesA.Enqueue(cliente);
                }
            }

            public void FinalizarAtencion()
            {
                if (colaClientesA.Count > 0)
                {
                    // Si la cola tiene clientes pendientes, atiende al siguiente
                    Cliente siguienteCliente = colaClientesA.Dequeue(); // Quita y obtiene el primer cliente de la cola
                    ClienteAtendido = siguienteCliente;
                    Estado = Estados.Ocupado;
                }
                else
                {
                    // Si la cola est� vac�a, el ayudante pasa a estado "Libre"
                    Estado = Estados.Libre;
                }
            }

            public void calcularFinDeVenta(double relojActual)
            {
                double numeroAleatorio = rnd_atencion_relojero.NextDouble();
                numeroAleatorio = Math.Round(numeroAleatorio * 1000) / 1000; // Redondea a 3 decimales
                double tiempo_atencion_relojero = Math.Truncate(6 + numeroAleatorio * (10 - 6));
                FinAtencion = (Math.Truncate((relojActual + tiempo_atencion_relojero) * 100)) / 100;

                // Llama al m�todo para finalizar la atenci�n
                FinalizarAtencion();
            }

            public double CalcularPorcentajeOcupacion()
            {
                return Estado == Estados.Ocupado ? 100 : 0;
            }
        }
        public class Relojero
        {
            public int RelojesPorReparar { get; set; }
            public int RelojesReparados { get; set; }
            public string Estado { get; set; }
            public double RndReparacionReloj { get; set; }
            public double TiempoReparacionReloj { get; set; }
            public double MomentoFinReparacion { get; set; }
            public double RndCafe { get; set; }
            public string Cafe { get; set; }
            public double TiempoCafe { get; set; }
            public double RelojFinCafe { get; set; }
            public Queue<Cliente> ColaRelojesPorReparar { get; set; } = new Queue<Cliente>();
            public Queue<Cliente> ColaRelojesParaRetirar { get; set; } = new Queue<Cliente>();
            private Random rndAtencionRelojero = new Random();
            private Random rndCafeGenerator = new Random();

            public Relojero()
            {
                RelojesReparados = 3;
                RelojesPorReparar = 0;
                Estado = "Libre";
            }

            public void RealizarReparacion(double relojActual)
            {
                if (RelojesPorReparar > 0)
                {
                    TiempoReparacionReloj = CalcularTiempoReparacion();
                    MomentoFinReparacion = relojActual + TiempoReparacionReloj;

                    if (RandomDouble() < 0.10)
                    {
                        MomentoFinReparacion += 5;
                    }

                    RelojesPorReparar--;
                    RelojesReparados++;
                    Estado = "Ocupado"; // Actualizar el estado a "Ocupado"
                }
                else
                {
                    Estado = "Libre"; // Si no hay relojes para reparar, el estado es "Libre"
                }
            }

            public void AgregarClienteReparacion(Cliente cliente)
            {
                ColaRelojesPorReparar.Enqueue(cliente);
            }

            public Cliente ObtenerSiguienteClienteReparacion()
            {
                if (ColaRelojesPorReparar.Count > 0)
                {
                    return ColaRelojesPorReparar.Dequeue(); // Quita y obtiene el primer cliente en la cola
                }
                return null; // Retorna null si la cola est� vac�a
            }

            public double CalcularTiempoReparacion()
            {
                double numeroAleatorio = rndAtencionRelojero.NextDouble();
                numeroAleatorio = Math.Round(numeroAleatorio * 1000) / 1000; // Redondea a 3 decimales
                return Math.Truncate(18 + numeroAleatorio * (22 - 18));
            }

            public string CalcularTiempoCafe()
            {
                double rndCafe = rndCafeGenerator.NextDouble();
                rndCafe = Math.Round(rndCafe * 1000) / 1000; // Redondea a 3 decimales
                if (rndCafe < 0.09)
                {
                    Cafe = "Toma Cafe";
                }
                else
                {
                    Cafe = "No";
                }
                return Cafe;
            }

            public double CalcularPorcentajeOcupacion()
            {
                return 100 * (3 - RelojesPorReparar) / 3;
            }

            private double RandomDouble()
            {
                return rndAtencionRelojero.NextDouble();
            }
        }
        private static double RandomDouble()
        {
            Random random = new Random();
            return random.NextDouble();
        }
    }
}

